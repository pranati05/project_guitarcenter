$(document).ready(function () {
    $('#sidenav li:has("ul")').children('ul').hide();
	
 $('#sidenav li:has("ul")').hover(function(){
    $(this).children('ul').slideDown('slow');
}, function(){
	 $(this).children('ul').slideUp('slow');
	 });


  $(".tabs-nav li a").click(function() {
        $('.tabs-nav li').removeClass("active");
        $(this).parent().addClass("active");
        $(".tab-content").hide();
       var activeTab = $(this).attr('href');
        $.ajax({ url: this.href, success: function(html) 
		{
			if(activeTab == 'page_1.html') 
			{
            $("#tabs-2").empty().append(html);
			$("#tabs-2").show();
            }
			else 
			{
				$(activeTab).show();
			}
		}
		});
 
        return false;
		
    });
    
$('.tabs-nav a:first').trigger('click'); // Default
  
});